const express = require('express');
const app = express();

app.use(express.json({ limit: '10mb' }));


app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  next();
});

app.post('/test', (req, res) => {
  console.log("=== Cookies Received ===");
  console.log(req.body);
  res.json({ status: "received safely" });
});

app.listen(3000, () => console.log("Safe lab server running on port 3000"));
